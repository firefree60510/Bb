package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.OrderItem
import com.example.data.model.PdfItem
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AdminViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    viewModel: AdminViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var showPostPdfDialog by remember { mutableStateOf(false) }
    var pdfToDelete by remember { mutableStateOf<PdfItem?>(null) }
    var viewingScreenshotUrl by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(uiState.actionSuccessMessage) {
        uiState.actionSuccessMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearActionMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin",
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (uiState.isLoggedIn) "Admin: ${uiState.adminName}" else "Admin Portal",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    if (uiState.isLoggedIn) {
                        IconButton(onClick = { viewModel.loadDashboardData() }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = Color.White
                            )
                        }
                        IconButton(onClick = { viewModel.logout() }) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Logout",
                                tint = Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D47A1),
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            if (uiState.isLoggedIn && uiState.selectedTab == 1) {
                FloatingActionButton(
                    onClick = { showPostPdfDialog = true },
                    containerColor = AmberAccent,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("admin_post_pdf_fab")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Post New PDF")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Post PDF", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (!uiState.isLoggedIn) {
                AdminLoginForm(
                    isLoading = uiState.isLoading,
                    loginError = uiState.loginError,
                    onLogin = { u, p -> viewModel.login(u, p) }
                )
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Admin Navigation Tabs
                    TabRow(
                        selectedTabIndex = uiState.selectedTab,
                        containerColor = Color.White,
                        contentColor = BluePrimary
                    ) {
                        Tab(
                            selected = uiState.selectedTab == 0,
                            onClick = { viewModel.selectTab(0) },
                            text = { Text("Orders (${uiState.orders.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        )
                        Tab(
                            selected = uiState.selectedTab == 1,
                            onClick = { viewModel.selectTab(1) },
                            text = { Text("Post & Delete PDFs", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        )
                        Tab(
                            selected = uiState.selectedTab == 2,
                            onClick = { viewModel.selectTab(2) },
                            text = { Text("QR & Social Links", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        )
                    }

                    when (uiState.selectedTab) {
                        0 -> AdminOrdersTab(
                            uiState = uiState,
                            onFilterChange = { viewModel.filterOrders(it) },
                            onApproveOrder = { order ->
                                viewModel.updateOrderStatus(order.orderId, "Approved", "Payment verified by Admin. Download active!")
                            },
                            onRejectOrder = { order ->
                                viewModel.updateOrderStatus(order.orderId, "Rejected", "Payment verification failed. Please contact on WhatsApp.")
                            },
                            onViewScreenshot = { url ->
                                if (!url.isNullOrEmpty()) {
                                    viewingScreenshotUrl = url
                                } else {
                                    Toast.makeText(context, "No screenshot available", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                        1 -> AdminManagePdfsTab(
                            pdfs = uiState.pdfs,
                            isLoading = uiState.isLoading,
                            onAddNewClick = { showPostPdfDialog = true },
                            onDeleteClick = { pdf -> pdfToDelete = pdf }
                        )
                        2 -> AdminQrAndLinksTab(
                            settings = uiState.appSettings,
                            isLoading = uiState.isLoading,
                            onSaveSettings = { upiId, upiName, announcement, whatsapp, youtube, telegram, qrUri ->
                                viewModel.saveSettings(upiId, upiName, announcement, whatsapp, youtube, telegram, qrUri)
                            }
                        )
                    }
                }
            }
        }
    }

    // Post PDF Dialog
    if (showPostPdfDialog) {
        PostPdfDialog(
            onDismiss = { showPostPdfDialog = false },
            onPost = { title, boardClass, subject, category, price, origPrice, desc, pages, size, year, downloadUrl ->
                viewModel.postNewPdf(title, boardClass, subject, category, price, origPrice, desc, pages, size, year, downloadUrl)
                showPostPdfDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    pdfToDelete?.let { pdf ->
        AlertDialog(
            onDismissRequest = { pdfToDelete = null },
            title = { Text("Delete PDF Post?", fontWeight = FontWeight.Bold, color = ErrorRed) },
            text = { Text("Are you sure you want to remove '${pdf.title}' from the store? Students will no longer see it.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePdf(pdf.id, pdf.title)
                        pdfToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Delete Post")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { pdfToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Full screen screenshot preview dialog
    viewingScreenshotUrl?.let { url ->
        AlertDialog(
            onDismissRequest = { viewingScreenshotUrl = null },
            title = { Text("Payment Proof Screenshot", fontWeight = FontWeight.Bold) },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = url,
                        contentDescription = "Payment Screenshot",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            },
            confirmButton = {
                Button(onClick = { viewingScreenshotUrl = null }) {
                    Text("Close")
                }
            }
        )
    }
}

// ---------------- TAB 0: ORDERS LIST ----------------
@Composable
private fun AdminOrdersTab(
    uiState: com.example.ui.viewmodel.AdminUiState,
    onFilterChange: (String) -> Unit,
    onApproveOrder: (OrderItem) -> Unit,
    onRejectOrder: (OrderItem) -> Unit,
    onViewScreenshot: (String?) -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            AdminStatsHeader(stats = uiState.stats)
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Orders (${uiState.orders.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("All", "Pending", "Approved", "Rejected").forEach { filter ->
                        val isSelected = uiState.selectedFilter.equals(filter, ignoreCase = true)
                        FilterChip(
                            selected = isSelected,
                            onClick = { onFilterChange(filter) },
                            label = { Text(filter, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        if (uiState.isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = BluePrimary)
                }
            }
        } else if (uiState.orders.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("No orders in this category.", color = Color.Gray)
                }
            }
        } else {
            items(uiState.orders, key = { it.orderId }) { order ->
                AdminOrderCard(
                    order = order,
                    onViewScreenshot = onViewScreenshot,
                    onApprove = { onApproveOrder(order) },
                    onReject = { onRejectOrder(order) },
                    onOpenWhatsApp = {
                        val msg = "Hello ${order.studentName}, regarding your Order ID: ${order.orderId} for ${order.pdfTitle}..."
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/91${order.whatsappNumber}?text=${Uri.encode(msg)}"))
                        context.startActivity(intent)
                    }
                )
            }
        }
    }
}

// ---------------- TAB 1: MANAGE PDFS (POST & DELETE) ----------------
@Composable
private fun AdminManagePdfsTab(
    pdfs: List<PdfItem>,
    isLoading: Boolean,
    onAddNewClick: () -> Unit,
    onDeleteClick: (PdfItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F0FE)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Live Store Posts: ${pdfs.size} PDFs", fontWeight = FontWeight.Bold, color = BluePrimary)
                        Text("You can delete any fake/old post or add new real materials with download link.", fontSize = 11.sp, color = Color.DarkGray)
                    }
                    Button(
                        onClick = onAddNewClick,
                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Post New", fontSize = 12.sp)
                    }
                }
            }
        }

        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = BluePrimary)
                }
            }
        } else if (pdfs.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("No PDFs in store. Click 'Post New' to add your first real PDF!", color = Color.Gray)
                }
            }
        } else {
            items(pdfs, key = { it.id }) { pdf ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = Color(0xFFE3F2FD),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "${pdf.boardClass} • ${pdf.subject}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BluePrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "₹${pdf.price.toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SuccessGreen
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = pdf.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                maxLines = 2
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Category: ${pdf.category} • Pages: ${pdf.pagesCount}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                        IconButton(
                            onClick = { onDeleteClick(pdf) },
                            modifier = Modifier.testTag("delete_pdf_${pdf.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete PDF",
                                tint = ErrorRed
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------- TAB 2: QR & SOCIAL LINKS ----------------
@Composable
private fun AdminQrAndLinksTab(
    settings: com.example.data.model.AppSettings,
    isLoading: Boolean,
    onSaveSettings: (
        upiId: String,
        upiName: String,
        announcement: String,
        whatsapp: String,
        youtube: String,
        telegram: String,
        qrUri: Uri?
    ) -> Unit
) {
    var upiId by remember(settings.upiId) { mutableStateOf(settings.upiId) }
    var upiName by remember(settings.upiName) { mutableStateOf(settings.upiName) }
    var whatsapp by remember(settings.whatsappNumber) { mutableStateOf(settings.whatsappNumber) }
    var announcement by remember(settings.announcement) { mutableStateOf(settings.announcement) }
    var youtubeUrl by remember(settings.youtubeUrl) { mutableStateOf(settings.youtubeUrl) }
    var telegramUrl by remember(settings.telegramUrl) { mutableStateOf(settings.telegramUrl) }
    var selectedQrUri by remember { mutableStateOf<Uri?>(null) }

    val qrPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedQrUri = uri
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // UPI QR Code Upload Box
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.QrCode, contentDescription = "QR", tint = BluePrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Admin UPI Payment QR Code", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFFBDBDBD), RoundedCornerShape(12.dp))
                        .background(Color(0xFFFAFAFA))
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedQrUri != null) {
                        AsyncImage(
                            model = selectedQrUri,
                            contentDescription = "New Selected QR",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else if (!settings.upiQrUrl.isNullOrEmpty()) {
                        AsyncImage(
                            model = settings.upiQrUrl,
                            contentDescription = "Current QR Code",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.Image, contentDescription = "No QR", tint = Color.Gray, modifier = Modifier.size(48.dp))
                            Text("No custom QR uploaded", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        qrPicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = "Choose QR")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (selectedQrUri != null || !settings.upiQrUrl.isNullOrEmpty()) "Change QR Image" else "Upload QR Code Image")
                }
            }
        }

        // Social Media & Channel Links Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Link, contentDescription = "Channels", tint = Color(0xFFD32F2F))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("YouTube & Telegram Channel Links", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                OutlinedTextField(
                    value = youtubeUrl,
                    onValueChange = { youtubeUrl = it },
                    label = { Text("YouTube Channel Link (https://youtube.com/@...)") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.PlayCircleFilled, contentDescription = "YT", tint = Color(0xFFD32F2F))
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = telegramUrl,
                    onValueChange = { telegramUrl = it },
                    label = { Text("Telegram Group/Channel Link (https://t.me/...)") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "TG", tint = Color(0xFF0288D1))
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // UPI & Support Details
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.CurrencyRupee, contentDescription = "UPI", tint = SuccessGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Receiving UPI & WhatsApp Details", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                OutlinedTextField(
                    value = upiId,
                    onValueChange = { upiId = it },
                    label = { Text("UPI ID (e.g. anujmaurya@upi or Paytm/PhonePe)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = upiName,
                    onValueChange = { upiName = it },
                    label = { Text("UPI Account Holder Name (e.g. Anuj Maurya)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = whatsapp,
                    onValueChange = { whatsapp = it },
                    label = { Text("WhatsApp Support Number (10 Digits)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = announcement,
                    onValueChange = { announcement = it },
                    label = { Text("Top Announcement Notice Bar") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Save Button
        Button(
            onClick = {
                onSaveSettings(upiId, upiName, announcement, whatsapp, youtubeUrl, telegramUrl, selectedQrUri)
            },
            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
            } else {
                Icon(imageVector = Icons.Default.Check, contentDescription = "Save")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save All Settings & Links", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

// ---------------- DIALOG: POST NEW PDF ----------------
@Composable
private fun PostPdfDialog(
    onDismiss: () -> Unit,
    onPost: (
        title: String,
        boardClass: String,
        subject: String,
        category: String,
        price: Double,
        origPrice: Double?,
        desc: String,
        pages: Int,
        size: String,
        year: String,
        downloadUrl: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var boardClass by remember { mutableStateOf("Class 10") }
    var subject by remember { mutableStateOf("Mathematics") }
    var category by remember { mutableStateOf("Notes") }
    var priceText by remember { mutableStateOf("39") }
    var origPriceText by remember { mutableStateOf("99") }
    var desc by remember { mutableStateOf("") }
    var pagesText by remember { mutableStateOf("50") }
    var sizeText by remember { mutableStateOf("8.5 MB") }
    var yearText by remember { mutableStateOf("2026") }
    var downloadUrl by remember { mutableStateOf("") }

    val categories = listOf("Notes", "Model Papers", "Previous Year Papers", "Important Questions", "Important Papers")
    val subjects = listOf("Mathematics", "Science", "Hindi", "Social Science", "English", "Sanskrit")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Post New PDF Material", fontWeight = FontWeight.Bold, color = BluePrimary) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("PDF Title / Subject Topic *") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Board Class Selector
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf("Class 10", "Class 9").forEach { cls ->
                        FilterChip(
                            selected = boardClass == cls,
                            onClick = { boardClass = cls },
                            label = { Text(cls) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Subject input
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject (e.g. Science, Mathematics)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Category selector
                Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Price (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = origPriceText,
                        onValueChange = { origPriceText = it },
                        label = { Text("Original Price (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = downloadUrl,
                    onValueChange = { downloadUrl = it },
                    label = { Text("Direct PDF / Google Drive Download Link *") },
                    placeholder = { Text("https://drive.google.com/...") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description / Highlights") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pagesText,
                        onValueChange = { pagesText = it },
                        label = { Text("Pages") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sizeText,
                        onValueChange = { sizeText = it },
                        label = { Text("File Size") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val p = priceText.toDoubleOrNull() ?: 29.0
                        val op = origPriceText.toDoubleOrNull()
                        val pages = pagesText.toIntOrNull() ?: 50
                        onPost(title, boardClass, subject, category, p, op, desc, pages, sizeText, yearText, downloadUrl)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
            ) {
                Text("Publish to App")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// ---------------- LOGIN FORM ----------------
@Composable
private fun AdminLoginForm(
    isLoading: Boolean,
    loginError: String?,
    onLogin: (String, String) -> Unit
) {
    var username by remember { mutableStateOf("anuj_admin") }
    var password by remember { mutableStateOf("admin123") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFFE8EAF6),
                    modifier = Modifier.size(64.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin",
                            tint = Color(0xFF0D47A1),
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text(text = "Admin Control Portal", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = BluePrimary)
                Text(text = "Post PDFs, manage QR, channels & payments", fontSize = 12.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(20.dp))

                loginError?.let {
                    Surface(
                        color = Color(0xFFFFEBEE),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = it,
                            color = ErrorRed,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = "User") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "Lock") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { onLogin(username, password) },
                    enabled = !isLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D47A1)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    } else {
                        Text("Login to Admin Panel", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatsHeader(stats: com.example.data.model.AdminStats) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatCard(
            title = "Total Orders",
            value = "${stats.totalOrders}",
            icon = Icons.Default.ShoppingBag,
            color = BluePrimary,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            title = "Pending",
            value = "${stats.pendingOrders}",
            icon = Icons.Default.PendingActions,
            color = AmberAccent,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            title = "Total Earned",
            value = "₹${stats.totalRevenue.toInt()}",
            icon = Icons.Default.CurrencyRupee,
            color = SuccessGreen,
            modifier = Modifier.weight(1.2f)
        )
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = color)
            Text(text = title, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun AdminOrderCard(
    order: OrderItem,
    onViewScreenshot: (String?) -> Unit,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onOpenWhatsApp: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = order.orderId, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BluePrimary)
                    Text(text = order.createdAt ?: "", fontSize = 10.sp, color = Color.Gray)
                }
                StatusBadge(status = order.status)
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = Color(0xFFEEEEEE))
            Spacer(modifier = Modifier.height(8.dp))

            Text(text = order.pdfTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Student: ${order.studentName}", fontSize = 12.sp, color = Color.DarkGray)
                Text(text = "Amount: ₹${order.pdfPrice.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
            }
            Text(text = "WhatsApp: +91 ${order.whatsappNumber}", fontSize = 12.sp, color = Color(0xFF00796B))
            order.utrNumber?.let { utr ->
                Text(text = "UTR / Ref: $utr", fontSize = 11.sp, color = Color(0xFF6A1B9A), fontWeight = FontWeight.Medium)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onViewScreenshot(order.screenshotUrl) },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Proof", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = onOpenWhatsApp,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("WhatsApp", fontSize = 11.sp)
                }

                if (order.status != "Approved") {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Text("Approve", fontSize = 11.sp)
                    }
                }

                if (order.status == "Pending") {
                    Button(
                        onClick = onReject,
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Reject", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
